#!/usr/bin/env python3
"""Make a tiny artificial panel/sample; NOT a real human marker library.

python tools/make_demo.py --out demo --x 2 --y 1 --trisomy 21
For a larger scan benchmark: --markers-per-chromosome 10000 --repeats 2
"""
import argparse
import gzip
from pathlib import Path
import random


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", type=Path, default=Path("demo"))
    p.add_argument("--markers-per-chromosome", type=int, default=100)
    p.add_argument("--repeats", type=int, default=16)
    p.add_argument("--x", type=int, default=2)
    p.add_argument("--y", type=int, default=1)
    p.add_argument("--trisomy", type=int, choices=range(1, 23), default=21)
    p.add_argument("--gzip", action="store_true")
    p.add_argument("--random-flanks", action="store_true", help="Use ACGT flanks for a more representative scanning benchmark")
    args = p.parse_args()
    if min(args.markers_per_chromosome, args.repeats) < 1 or min(args.x, args.y) < 0:
        p.error("marker count/repeats must be positive; dosage cannot be negative")
    args.out.mkdir(parents=True, exist_ok=True)
    rng = random.Random(20261026)
    library = args.out / "synthetic.markers.tsv"
    fastq = args.out / ("synthetic.fastq.gz" if args.gzip else "synthetic.fastq")
    seen = set()
    translation = str.maketrans("ACGT", "TGCA")
    flanks = [("".join(rng.choices("ACGT", k=59)), "".join(rng.choices("ACGT", k=60))) for _ in range(4096)] if args.random_flanks else None
    number = 0
    with library.open("w") as lib, (gzip.open(fastq, "wt", compresslevel=1) if args.gzip else fastq.open("w")) as reads:
        lib.write("# ARTIFICIAL DEMO ONLY: these are not human reference markers\n# kmer chromosome bin\n")
        for chrom in [str(i) for i in range(1, 23)] + ["X", "Y"]:
            copies = args.x if chrom == "X" else args.y if chrom == "Y" else 3 if chrom == str(args.trisomy) else 2
            for m in range(args.markers_per_chromosome):
                while True:
                    word = "".join(rng.choices("ACGT", k=31))
                    canonical = min(word, word.translate(translation)[::-1])
                    if canonical not in seen:
                        seen.add(canonical)
                        break
                lib.write(f"{word}\t{chrom}\tbin{m % 20:02d}\n")
                for rep in range(copies * args.repeats):
                    marker = word if rep % 2 == 0 else word.translate(translation)[::-1]
                    # N padding gives exactly one occurrence/read. Random flanks
                    # exercise all sliding positions, but are still synthetic.
                    left, right = flanks[rng.randrange(len(flanks))] if flanks else ("N" * 59, "N" * 60)
                    seq = left + marker + right
                    reads.write(f"@synthetic{number}\n{seq}\n+\n{'I' * len(seq)}\n")
                    number += 1
    print(f"Library: {library}\nFASTQ: {fastq}\nReads: {number}\nExpected: chr{args.trisomy}=3, X={args.x}, Y={args.y}; other autosomes=2")
    print("For this small demo add: --min-markers 20 --min-expected-hits 100")


if __name__ == "__main__":
    main()
