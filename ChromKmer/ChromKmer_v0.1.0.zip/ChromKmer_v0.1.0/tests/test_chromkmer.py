"""Synthetic correctness checks; these do NOT establish human WGS accuracy."""
import csv
import gzip
import json
import os
from pathlib import Path
import random
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
EXE = Path(os.environ.get("CHROMKMER_BIN", ROOT / "chromkmer"))
DNA = "ACGT"


def rc(s):
    return s.translate(str.maketrans("ACGTacgt", "TGCAtgca"))[::-1]


def canonical(s):
    return min(s.upper(), rc(s.upper()))


class ChromKmerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name)
        self.rng = random.Random(1701)
        self.library = self.path / "markers.tsv"
        self.markers = {}
        used = set()
        # Deliberately unequal panel sizes test marker-count normalization.
        for c in [str(i) for i in range(1, 23)] + ["X", "Y"]:
            self.markers[c] = []
            for _ in range(25 + (int(c) % 4 if c.isdigit() else 0)):
                while True:
                    s = "".join(self.rng.choices(DNA, k=21))
                    if canonical(s) not in used:
                        used.add(canonical(s))
                        self.markers[c].append(s)
                        break
        self.write_library()
        self.counter = 0

    def tearDown(self):
        self.tmp.cleanup()

    def write_library(self, binned=True, path=None):
        path = path or self.library
        with open(path, "w") as f:
            f.write("# Synthetic panel, not a usable human marker library\n")
            f.write("kmer chromosome" + (" bin" if binned else "") + "\n")
            for c, markers in self.markers.items():
                for i, s in enumerate(markers):
                    f.write(f"{s}\tchr{c}" + (f"\tbin{i % 5}" if binned else "") + "\n")

    def fastq(self, reads, name="reads.fq", compressed=False, wrap=False):
        path = self.path / name
        with (gzip.open(path, "wt") if compressed else open(path, "w")) as f:
            for i, item in enumerate(reads):
                s, q = item if isinstance(item, tuple) else (item, "I" * len(item))
                if wrap:
                    f.write(f"@r{i}\n{s[:7]}\n{s[7:]}\n+\n{q[:9]}\n{q[9:]}\n")
                else:
                    f.write(f"@r{i}\n{s}\n+\n{q}\n")
        return path

    def dosage_reads(self, dosage=None, long=False):
        dosage = dosage or {}
        reads = []
        for c, markers in self.markers.items():
            copies = dosage.get(c, 1 if c in ("X", "Y") else 2)
            for s in markers:
                for i in range(round(copies * 8)):
                    reads.append(s if i % 2 == 0 else rc(s))
        self.rng.shuffle(reads)
        if long:
            reads = ["NN".join(reads[i:i+173]) for i in range(0, len(reads), 173)]
        return reads

    def run_tool(self, fastq, extra=(), library=None, ok=True, defaults=True, stdin=None):
        self.counter += 1
        prefix = self.path / f"out{self.counter}"
        cmd = [str(EXE), "--library", str(library or self.library), "-o", str(prefix)]
        for path in fastq:
            cmd += ["--fastq", str(path)]
        if defaults:
            cmd += ["--min-markers", "1", "--min-expected-hits", "1"]
        cmd += list(extra)
        p = subprocess.run(cmd, input=stdin, text=True, capture_output=True, timeout=40)
        if not ok:
            self.assertNotEqual(p.returncode, 0, p.stderr)
            self.assertFalse(prefix.with_suffix(".report.json").exists())
            self.assertFalse(list(self.path.glob(prefix.name + "*.tmp.*")))
            return p
        self.assertEqual(p.returncode, 0, p.stderr)
        with open(str(prefix) + ".chromosomes.tsv") as f:
            rows = {r["chromosome"]: r for r in csv.DictReader(f, delimiter="\t")}
        return rows, json.loads(Path(str(prefix) + ".report.json").read_text())

    def test_trisomy21_and_different_panel_sizes(self):
        fq = self.fastq(self.dosage_reads({"21": 3}))
        rows, report = self.run_tool([fq])
        for c in self.markers:
            self.assertAlmostEqual(float(rows[c]["copy_number"]), 3 if c == "21" else 1 if c in ("X", "Y") else 2)
        self.assertEqual(rows["21"]["call"], "TRISOMY_CANDIDATE")
        self.assertEqual(report["autosomal_change_candidates"][0]["chromosome"], "21")

    def test_sex_chromosome_patterns(self):
        for pattern, x, y in [("X0", 1, 0), ("XY", 1, 1), ("XX", 2, 0), ("XYY", 1, 2), ("XXY", 2, 1), ("XXX", 3, 0), ("XXYY", 2, 2)]:
            with self.subTest(pattern=pattern):
                fq = self.fastq(self.dosage_reads({"X": x, "Y": y}))
                rows, report = self.run_tool([fq])
                self.assertEqual(report["sex_chromosome_pattern_candidate"], pattern)
                self.assertEqual(int(rows["X"]["nearest_integer_candidate"]), x)
                self.assertEqual(int(rows["Y"]["nearest_integer_candidate"]), y)

    def test_multiple_autosomal_gains_and_losses(self):
        rows, report = self.run_tool([self.fastq(self.dosage_reads({"7": 1, "13": 0, "18": 3, "21": 4}))])
        for c, copies, call in [("7", 1, "MONOSOMY_CANDIDATE"), ("13", 0, "ABSENT_CANDIDATE"), ("18", 3, "TRISOMY_CANDIDATE"), ("21", 4, "GAIN_CANDIDATE")]:
            self.assertEqual(float(rows[c]["copy_number"]), copies)
            self.assertEqual(rows[c]["call"], call)
        self.assertEqual(len(report["autosomal_change_candidates"]), 4)

    def test_uniform_genome_doubling_is_not_identifiable(self):
        dosage = {str(c): 4 for c in range(1, 23)}
        dosage.update(X=2, Y=2)
        rows, report = self.run_tool([self.fastq(self.dosage_reads(dosage))])
        self.assertEqual(float(rows["1"]["copy_number"]), 2)
        self.assertEqual(report["sex_chromosome_pattern_candidate"], "XY")

    def test_thread_determinism(self):
        fq = self.fastq(self.dosage_reads({"21": 3}), compressed=True, name="reads.gz")
        a, x = self.run_tool([fq], ["-t", "1", "--batch-bases", "1000", "--queue-batches", "1"])
        b, y = self.run_tool([fq], ["-t", "4", "--batch-bases", "1000", "--queue-batches", "2"])
        self.assertEqual(a, b)
        for field in ("reads", "bases", "valid_kmer_positions", "marker_occurrences", "matched_reads"):
            self.assertEqual(x[field], y[field])

    def test_short_long_equivalence(self):
        reads = self.dosage_reads({"21": 1.5, "Y": 0})
        a, _ = self.run_tool([self.fastq(reads)])
        long_reads = ["N".join(reads[i:i+91]) for i in range(0, len(reads), 91)]
        b, _ = self.run_tool([self.fastq(long_reads, name="long.fq")])
        self.assertEqual(a, b)
        self.assertEqual(float(a["21"]["copy_number"]), 1.5)
        self.assertEqual(a["21"]["call"], "UNCERTAIN")

    def test_multiple_files_and_wrapped_crlf_gzip(self):
        reads = self.dosage_reads()
        a, _ = self.run_tool([self.fastq(reads)])
        left = self.fastq(reads[::2], name="R1.gz", compressed=True, wrap=True)
        right = self.fastq(reads[1::2], name="R2.fq", wrap=True)
        right.write_bytes(right.read_bytes().replace(b"\n", b"\r\n"))
        b, _ = self.run_tool([left, right])
        self.assertEqual(a, b)

    def test_stdin(self):
        fq = self.fastq(self.dosage_reads())
        a, _ = self.run_tool([fq])
        b, _ = self.run_tool(["-"], stdin=fq.read_text())
        self.assertEqual(a, b)

    def test_independent_naive_oracle_with_quality_and_ambiguity(self):
        rng = self.rng
        reads = self.dosage_reads()
        reads += ["acgtnRY" + rc(self.markers["21"][0]).lower() + "N" + self.markers["Y"][0]]
        reads += ["".join(rng.choices(DNA + "N", k=217)) for _ in range(80)]
        reads = ["N".join(reads[i:i+13]) for i in range(0, len(reads), 13)]
        pairs = []
        for s in reads:
            q = "".join("!" if rng.random() < .015 else "I" for _ in s)
            pairs.append((s, q))
        lookup = {canonical(s): c for c, markers in self.markers.items() for s in markers}
        expected = dict.fromkeys(self.markers, 0)
        valid = total = 0
        for s, q in pairs:
            for i in range(len(s) - 20):
                word = s[i:i+21].upper()
                if not set(word) <= set(DNA) or min(ord(ch) - 33 for ch in q[i:i+21]) < 20:
                    continue
                valid += 1
                c = lookup.get(canonical(word))
                if c:
                    expected[c] += 1
                    total += 1
        rows, report = self.run_tool([self.fastq(pairs)], ["--min-baseq", "20"])
        self.assertEqual({c: int(r["hits"]) for c, r in rows.items()}, expected)
        self.assertEqual(report["valid_kmer_positions"], valid)
        self.assertEqual(report["marker_occurrences"], total)

    def test_all_occurrences_not_read_classification(self):
        s = self.markers["21"][0]
        reads = self.dosage_reads() + ["N".join([s] * 12)]
        rows, report = self.run_tool([self.fastq(reads)])
        self.assertEqual(int(rows["21"]["hits"]), 16 * len(self.markers["21"]) + 12)
        self.assertGreater(report["marker_occurrences"], report["matched_reads"])

    def test_duplicate_and_reverse_complement_duplicate_rejected(self):
        original = self.library.read_text()
        for extra in [self.markers["1"][0], rc(self.markers["1"][0])]:
            self.library.write_text(original + f"{extra}\tY\tother\n")
            p = self.run_tool([self.fastq(self.dosage_reads())], ok=False)
            self.assertIn("Duplicate canonical", p.stderr)

    def test_invalid_library(self):
        for content in ["", "AAAA 1\nAAAAA 2\n", "ACNT 1\n", "ACGT MT\n", "A" * 32 + " 1\n", "ACGT 1 bin extra\n", "ACGT 1\nAGCT 1 b\n"]:
            with self.subTest(content=content):
                self.library.write_text(content)
                self.run_tool([self.fastq(["ACGT"])], ok=False)

    def test_missing_chromosome_is_not_inferred_absent(self):
        del self.markers["Y"]
        self.write_library()
        rows, report = self.run_tool([self.fastq(self.dosage_reads())])
        self.assertEqual(rows["Y"]["copy_number"], "NA")
        self.assertEqual(rows["Y"]["call"], "NOT_ASSESSED")
        self.assertEqual(report["sex_chromosome_pattern_candidate"], "UNRESOLVED")

    def test_insufficient_baseline_no_outputs(self):
        self.run_tool([self.fastq(self.dosage_reads())], defaults=False, ok=False)

    def test_low_marker_and_low_expected_hits_suppress_calls(self):
        self.markers["Y"] = self.markers["Y"][:1]
        self.write_library()
        rows, report = self.run_tool([self.fastq(self.dosage_reads({"Y": 0}))], ["--min-markers", "20", "--min-expected-hits", "20"])
        self.assertEqual(rows["Y"]["call"], "UNCERTAIN")
        self.assertIn("TOO_FEW_MARKERS", rows["Y"]["qc"])
        self.assertIn("LOW_EXPECTED_HITS", rows["Y"]["qc"])
        self.assertEqual(report["sex_chromosome_pattern_candidate"], "UNRESOLVED")

    def test_dispersed_baseline_suppresses_integer_calls(self):
        dosage = {str(c): 1 if c <= 8 else 2 if c <= 15 else 3 for c in range(1, 23)}
        rows, report = self.run_tool([self.fastq(self.dosage_reads(dosage))])
        self.assertFalse(report["baseline_basic_qc_passed"])
        self.assertTrue(all(r["nearest_integer_candidate"] == "NA" for r in rows.values()))

    def test_bin_heterogeneity_suppresses_call(self):
        reads = []
        for c, markers in self.markers.items():
            for i, s in enumerate(markers):
                n = (40 if i % 5 == 0 else 0) if c == "21" else 8 if c in ("X", "Y") else 16
                reads.extend([s] * n)
        rows, _ = self.run_tool([self.fastq(reads)])
        self.assertIn("BIN_HETEROGENEITY_HIGH", rows["21"]["qc"])
        self.assertEqual(rows["21"]["call"], "UNCERTAIN")

    def test_malformed_fastq_and_truncated_gzip(self):
        for content in ["", "read\nACGT\n+\nIIII\n", "@r\nACGT\n+\nIII\n", "@r\nACGT\n+\nIIIII\n", "@r\nACGT\n+\nII I\n", "@r\nAC GT\n+\nIIIII\n"]:
            fq = self.path / "bad.fq"
            fq.write_text(content)
            self.run_tool([fq], ok=False)
        fq = self.fastq(self.dosage_reads(), name="truncated.gz", compressed=True)
        fq.write_bytes(fq.read_bytes()[:-5])
        p = self.run_tool([fq], ok=False)
        self.assertIn("decompression error", p.stderr)

    def test_memory_guard_and_max_read(self):
        self.run_tool([self.fastq(["A" * 100])], ["--max-read-bases", "99"], ok=False)
        # A sufficiently large library must trip the cap before input scanning.
        seen = set()
        with open(self.library, "w") as f:
            while len(seen) < 40000:
                s = "".join(self.rng.choices(DNA, k=21))
                if canonical(s) not in seen:
                    seen.add(canonical(s))
                    f.write(f"{s}\t1\n")
        p = self.run_tool([self.fastq(["A" * 100])], ["--max-table-mb", "1"], ok=False)
        self.assertIn("Lookup table needs", p.stderr)

    def test_output_protection_and_repeat_input(self):
        fq = self.fastq(self.dosage_reads())
        self.run_tool([fq])
        prefix = self.path / f"out{self.counter}"
        before = {p.name: p.read_bytes() for p in self.path.glob(prefix.name + ".*")}
        p = subprocess.run([str(EXE), "--library", str(self.library), "--fastq", str(fq), "-o", str(prefix)], capture_output=True, text=True)
        self.assertNotEqual(p.returncode, 0)
        self.assertIn("Output exists", p.stderr)
        self.assertEqual(before, {p.name: p.read_bytes() for p in self.path.glob(prefix.name + ".*")})
        subprocess.run([str(EXE), "--library", str(self.library), "--fastq", str(fq), "-o", str(prefix), "--min-markers", "1", "--min-expected-hits", "1", "--force"], check=True, capture_output=True)

    def test_duplicate_input_rejected(self):
        fq = self.fastq(self.dosage_reads())
        p = self.run_tool([fq, fq], ok=False)
        self.assertIn("Repeated FASTQ input", p.stderr)

    def test_k31_boundaries_and_unbinned_library(self):
        self.markers = {}
        for c in [str(i) for i in range(1, 7)] + ["X", "Y"]:
            self.markers[c] = ["".join(self.rng.choices(DNA, k=31)) for _ in range(10)]
        # Key zero is valid; reverse-complement canonicalization must preserve it.
        self.markers["1"][0] = "A" * 31
        self.write_library(binned=False)
        rows, report = self.run_tool([self.fastq(self.dosage_reads(long=True))])
        self.assertEqual(report["k"], 31)
        self.assertEqual(float(rows["1"]["copy_number"]), 2)
        self.assertEqual(report["sex_chromosome_pattern_candidate"], "XY")

    def test_compressed_library(self):
        gz = self.path / "markers.gz"
        with gzip.open(gz, "wt") as f:
            f.write(self.library.read_text())
        a, _ = self.run_tool([self.fastq(self.dosage_reads())])
        b, _ = self.run_tool([self.fastq(self.dosage_reads())], library=gz)
        self.assertEqual(a, b)

    def test_custom_baseline_and_missing_baseline_chromosome(self):
        rows, report = self.run_tool([self.fastq(self.dosage_reads({"21": 3}))], ["--baseline", "1,2,3,4,5"])
        self.assertEqual(report["baseline_chromosomes"], ["1", "2", "3", "4", "5"])
        self.assertEqual(float(rows["21"]["copy_number"]), 3)
        del self.markers["5"]
        self.write_library()
        p = self.run_tool([self.fastq(self.dosage_reads())], ["--baseline", "1,2,3,4,5"], ok=False)
        self.assertIn("missing from library", p.stderr)


if __name__ == "__main__":
    unittest.main()
