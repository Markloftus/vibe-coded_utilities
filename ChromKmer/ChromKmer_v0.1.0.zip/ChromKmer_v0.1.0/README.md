# ChromKmer 0.1.0

**FASTQ + a chromosome k-mer library → relative chromosome copy number.**

ChromKmer is a standalone C++17 command-line program for whole-genome DNA
sequencing. It streams plain/gzipped FASTQ, counts exact marker occurrences on
both strands, normalizes for the number of markers on each chromosome, and
compares each chromosome to the median signal across usable autosomes.
It needs no BAM, reference FASTA, aligner, or BED during sample analysis.

It reports continuous dosage and provisional integer candidates, including
autosomal gains/losses and sex-chromosome patterns X0, XX, XY, XXX, XXY, XYY,
and XXYY. These are **experimental research screening candidates**. The code
has synthetic correctness tests; it has not been validated for real-sample
aneuploidy accuracy. It does not provide diagnostic calls or a measured false
positive rate.

## Install using conda

Linux/macOS (native Windows is not supported; WSL can be used):

```bash
conda env create -f environment.yml
conda activate chromkmer
make -j4
make install PREFIX="$CONDA_PREFIX"
chromkmer --help
```

This builds the native executable once. Subsequent runs need only the active
environment. Runtime dependencies are the C++ runtime and zlib. Python is
included for tests and generating the demo, not for the counter itself.
The compiler and make are installation-time dependencies.

The `conda-recipe/` directory supports building a precompiled conda package;
that recipe is supplied but has not been built or published to a channel.
No `conda install chromkmer` channel is currently available. The source build
was tested with GCC 13 on Linux; conda installation and macOS need verification.

## Run

```bash
chromkmer \
  --fastq sample.fastq.gz \
  --library human.markers.tsv.gz \
  --threads 8 \
  --output results/sample
```

Supply both mates, lanes, or long-read files with repeated `--fastq`:

```bash
chromkmer \
  --fastq sample_R1.fastq.gz \
  --fastq sample_R2.fastq.gz \
  --library human.markers.tsv \
  --threads 8 --output results/sample
```

All files must belong to **one sample**. Files are processed in order by the
reader; batches are scanned by counting workers in parallel. Pairing/read
names are not used: both mates contribute their observed k-mer occurrences.
Do not supply R1/R2 again as merged reads or mix samples. Repeated identical
input paths are rejected, but copies or hard links cannot be identified as
duplicate data. There is no PCR duplicate or overlapping-mate removal.

Stdin is supported once, including gzipped stdin:

```bash
cat sample.fastq | chromkmer --fastq - --library human.markers.tsv -t 8 -o sample
```

FASTQ may use wrapped sequence/quality lines and Unix/Windows line endings.
Empty reads, malformed records, invalid quality characters, truncated FASTQ,
and detected gzip decompression errors are rejected. Non-ACGT sequence symbols
break the rolling k-mer: no marker can cross such a base. Lowercase is accepted.
The maximum read length defaults to 10 million bases and is configurable.

## K-mer library format

Whitespace-separated text (usually TSV), plain or gzip, with **two columns**:

```text
# kmer chromosome
ACGTTGCAAGTCGATCGTACGATTCGATGCA 1
TGCATACCGATGCTAACGTTAGCGATCATGC 21
GATCCGTACGTTACAGGCTATCGACGTAGCA X
CGTACGATGCTAGTACCGATTCGAGTACGCA Y
```

Those four illustrative rows are not a validated human panel.
Names `1` through `22`, `X`, `Y`, and their `chr`-prefixed forms are accepted.
Mitochondrial/non-primary contigs are not dosage targets. Comments beginning
with `#` and a `kmer chromosome [bin]` header are accepted. Unknown chromosome
names, extra columns, mixed k lengths, invalid DNA and duplicate canonical
markers are rejected rather than silently changed.

An optional third column assigns each marker to a genomic bin:

```text
# kmer chromosome bin
ACGTTGCAAGTCGATCGTACGATTCGATGCA 1 chr1_01000000_01100000
TGCATACCGATGCTAACGTTAGCGATCATGC 21 chr21_20000000_20100000
```

Bin labels have no spaces and must be stable within each chromosome. They
are labels, not coordinates parsed by the program. Explicit bins are useful
for checking whether a change is spread across the chromosome. Use actual
genomic bins; do not randomly label markers from unrelated regions. A
chromosome cannot mix binned and unbinned rows. Unbinned libraries work, but
the result carries `LIMITED_BIN_QC`.

### Biological requirements for a usable library

* All markers must have the **same k**, up to **31 bases**. Values 1–31 are
  technically supported for testing; very short k cannot provide useful
  globally unique human markers. Choose/validate k for the data and panel.
* Each marker must occur **once per haploid reference genome**, with a k-mer
  and its reverse complement treated as one marker. Being exclusive to a
  chromosome is insufficient if it occurs many times on that chromosome.
* Global uniqueness must be established upstream against the **whole supplied
  reference**, including relevant alternative/decoy sequences. Canonical
  duplicates in the supplied list are rejected, but ChromKmer cannot check
  uniqueness or copy count in a reference it has not been given.
* Use widely distributed, stable single-copy sequence; avoid common CNVs and
  highly polymorphic sites. Overlapping markers are allowed, but their counts
  are correlated, not independent observations.
* Match GC content and other sequence properties between chromosome panels
  and baseline autosomes. This version does **not** correct GC bias or learn
  chromosome-specific detection efficiencies.
* X/Y markers must come from appropriate **non-PAR single-copy sequence** and
  avoid X/Y homology. A usable Y marker panel must actually be supplied to
  distinguish zero Y signal from unassessed Y.
* Keep source-build, selection rules and provenance in library comments.
  Reference-derived markers may be absent or duplicated in individual
  samples; syntactic library checks cannot rule that out.

There is no real human marker library bundled. Building and validating it is
a separate step. The only bundled library generator produces artificial test
data and must not be used as a human reference panel.

## Calculation

For chromosome `c`, let `H_c` be all observed matching marker occurrences and
`M_c` the number of library markers assigned to it:

```text
marker_signal_c = H_c / M_c
baseline = median(marker_signal_c across usable baseline autosomes)
copy_number_c = 2 × marker_signal_c / baseline
```

For example, autosomes at 20 hits/marker define the two-copy baseline:

| Chromosome signal | Relative copy number |
| --- | ---: |
| 0 hits/marker | 0 |
| 10 hits/marker | 1 |
| 20 hits/marker | 2 |
| 30 hits/marker | 3 |

Consequently, X≈1/Y≈0 gives an X0 pattern candidate, X≈1/Y≈2 gives XYY,
and X≈2/Y≈1 gives XXY. Chromosome 21≈3 gives a trisomy-21 candidate if QC
passes. Fractional estimates are kept; 1.5 is not automatically called
mosaicism. Mixture, technical bias and partial-chromosome changes can all
produce noninteger whole-chromosome dosage.

This is marker abundance, **not directly measured per-base depth**. For a
marker to be observed, a read must span it and the entire word must match.
For uniform sampling, the expected count is proportional to copy number,
read-span opportunities and marker survival. The latter factors cancel only
to the extent that detection efficiency is comparable across chromosomes.
There is no need to know read length to form that relative ratio. Exact
matching works with short and long reads; error-prone long reads lose more
marker occurrences. Chromosome-dependent errors, variants and GC bias can
distort dosage. No platform-specific correction is implemented.

Every matching occurrence is counted, including several markers in one read
and repeated observations of a marker. No read is forced into a single
chromosome category. Forward and reverse complement matches count once per
read position. By default all printable Phred+33 qualities are retained;
`--min-baseq 20` requires every base of a matching k-mer to pass Q20.
Quality filtering can change detection efficiency and needs validation too.

## Baseline and calls

By default, baseline autosomes are chromosomes 1–22 present in the library
that have at least `--min-markers 1000` markers and at least
`2 × --min-expected-hits` observed occurrences. The median across chromosome
signals gives each contributing autosome equal weight. The majority of
contributing autosomes must be disomic and representative of the other
chromosomes. Excluded low-signal chromosomes are reported; their baseline
eligibility does not cause their own counts to be dropped from the output.

At least `--min-baseline 5` contributing autosomes are required (the option
cannot be set below 3). A user can choose a set of known controls:

```bash
chromkmer --fastq sample.fq.gz --library markers.tsv \
  --baseline 1,2,3,4,5,6,7,8 --threads 8 --output sample
```

QC/call rules are intentionally transparent and **heuristic**, not calibrated:

* Relative baseline MAD (median absolute deviation / median) above 0.15
  suppresses all integer candidates while retaining continuous estimates.
* A chromosome needs at least 1,000 markers and 1,000 **expected hits for a
  single copy**, calculated from the autosomal baseline. This allows zero
  Y signal to be assessed without requiring observed Y hits. It is a
  coverage gate, not a statistical detection limit.
* CN must lie within 0.25 of an integer; otherwise the integer is `NA`.
* With at least five explicitly labeled bins, a bin-signal CV above 0.5
  suppresses the chromosome's integer candidate. This diagnostic is not
  CNV segmentation or a validated test, and unequal/correlated bins affect it.
* No markers means `NOT_ASSESSED`, **not copy number zero**.
* If too few baseline autosomes qualify, the program exits with an error
  rather than producing unnormalized estimates.

Thresholds can be changed with the flags in `--help`. Relaxing them does not
establish biological accuracy. There are no confidence intervals, reference
cohort calibration, significance tests, clinical sensitivity/specificity
estimates, or automatic mixture/sex inference beyond dosage-pattern matching.
Uniform whole-genome ploidy changes cannot be detected from relative ratios.
Targeted sequencing, RNA/exome data, cfDNA mixtures and highly aneuploid tumors
do not satisfy the same simple baseline assumptions.

## Output files

| File | Contents |
| --- | --- |
| `PREFIX.chromosomes.tsv` | All 24 nuclear chromosomes; marker counts, hits, normalized signal, continuous CN, provisional integer/call, QC |
| `PREFIX.bins.tsv` | Per-bin marker counts, hits and relative CN; one group per chromosome when no bins were supplied |
| `PREFIX.report.json` | Run parameters, throughput, counts, library fingerprint, baseline, sex-chromosome pattern and autosomal change candidates |

`LIMITED_BIN_QC` flags a lack of regional checking; it does not by itself
suppress an integer candidate. Other call-blocking reasons are described
above. Bin CV is undefined (`NA`) for zero signal. Reported integer values
are provisional; the continuous `copy_number` column remains available.
Results are protected unless `--force` is specified. Files are staged and
renamed after successful computation; the three final renames are not an
atomic multi-file transaction. Do not run two processes with the same prefix.

## Performance and memory

* A compact 64-bit, two-bit-per-base canonical key represents each k-mer.
* One read-only open-addressed hash table is shared across all counting
  threads. A Bloom prefilter avoids most unnecessary hash-table probes;
  **every reported hit is verified against the full exact key**.
* Each table slot occupies 16 bytes; the table is a power of two with load
  below 2/3. The Bloom filter uses the next power of two above 8 bits/marker.
  One million markers require about **33 MiB for these two structures**;
  ten million require about **272 MiB**. These are table allocation sizes,
  not total process RSS.
* No per-marker hit array or per-base genome array is allocated. Each worker
  has an 8-byte counter per chromosome/bin, not a separate marker table.
* The library is streamed twice: once for metadata/size and once for insertion.
  Library-load time is reported separately. No binary-index cache is supplied.
* Reads are held in a bounded queue: default batches contain about one million
  bases, with at most twice the worker count waiting. Queue memory also
  depends on read length, per-read string overhead, quality filtering and
  active worker batches. Input is never loaded in full. Increasing threads
  increases queue and worker memory but does not replicate the marker table.
* `--max-table-mb 2048` guards table/Bloom allocation only, not total RSS.
  `--batch-bases`, `--queue-batches` and `--max-read-bases` control read buffers.
* One reader handles FASTQ parsing and gzip decompression. The rolling
  scanning/lookup runs across `--threads` workers; total threads are workers
  plus the main reader. Gzip, disk I/O or parsing can limit scaling. No
  universal throughput or linear speedup is promised.

See `VALIDATION.md` for measured synthetic results and untested areas.

## Tests and artificial demo

```bash
make test
python tools/make_demo.py --out demo --x 2 --y 1 --trisomy 21
chromkmer --fastq demo/synthetic.fastq \
  --library demo/synthetic.markers.tsv --threads 4 \
  --min-markers 20 --min-expected-hits 100 --output demo/result
```

The demo should report chromosome 21≈3, X≈2/Y≈1 and XXY as the sex-chromosome
pattern candidate. Its smaller thresholds are for a deliberately tiny
artificial panel, not recommended settings for human samples.

The tests independently compare exact counts with a naive Python oracle and
check strand handling, unequal panel sizes, thread determinism, quality/N
handling, synthetic gains/losses, missing chromosomes, malformed inputs and QC.

## Scope of this first version

The FASTQ counter and dosage calculation are implemented. Remaining scientific
work is marker-panel construction and validation against known human samples,
both read-length classes and platforms, depth downsampling and regional CNVs.
Detection limits for low-level mosaicism/contamination have not been measured.
The conda package recipe and macOS build still need independent installation
testing. This package does not include the earlier BAM prototype or a region
selection notebook.
