#!/usr/bin/env bash
set -euo pipefail
make -j"${CPU_COUNT:-2}"
make install PREFIX="$PREFIX"
