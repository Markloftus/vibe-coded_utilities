# Validation record — 2026-10-26

## Correctness

24 unittest methods passed with the optimized Linux executable. These cover:

* Equal dosage despite deliberately unequal numbers of library markers.
* Trisomy 21, monosomy, zero chromosome signal, four-copy gain, several
  simultaneous autosomal changes, and fractional dosage.
* X0, XX, XY, XXX, XXY, XYY and XXYY pattern candidates.
* One- and four-worker equality, small queues and small batches.
* Short reads and longer reads with the same exact marker occurrences.
* An independent naive Python sliding-word oracle with reverse complements,
  lowercase sequence, ambiguous bases, low quality and random decoy sequence.
* All occurrences counted when one read contains multiple markers.
* Plain/gzipped libraries and FASTQ, multiple input files, wrapped/CRLF FASTQ,
  and stdin.
* Mixed/invalid k-mers, duplicate/reverse-complement-duplicate markers, missing
  chromosomes, malformed/truncated FASTQ and truncated gzip rejection.
* Memory allocation guard, read length guard, duplicate input path rejection,
  output protection and explicit overwrite.
* Insufficient baseline evidence, dispersed autosomes, regional heterogeneity,
  low marker/evidence thresholds and custom baseline controls.
* Failure to identify uniform genome doubling, as expected for a relative
  dosage method.

The same 24 tests passed under GCC AddressSanitizer + UndefinedBehaviorSanitizer
with leak detection disabled. LeakSanitizer cannot inspect process threads in
this environment, so leak detection is **not** claimed. No ASan/UBSan findings
were reported in the completed run.

```bash
make test
# Optional instrumented build on a supported development machine:
g++ -std=c++17 -O1 -g -fsanitize=address,undefined \
  -fno-omit-frame-pointer -pthread src/chromkmer.cpp -lz -o chromkmer_asan
ASAN_OPTIONS=detect_leaks=0 CHROMKMER_BIN="$PWD/chromkmer_asan" \
  python3 -m unittest discover -s tests -v
```

Full test output is in `test-results.txt` and `sanitizer-test-results.txt`.

## Small synthetic throughput measurement

Input was 960,000 reads of 150 bases (144 million sequence bases), with
240,000 distinct canonical 31-mer markers, 10,000 per nuclear chromosome.
Reads contained one intended marker and random ACGT flanks, so all 120
sliding positions/read were eligible. The counter examined 115.2 million
positions and reported exactly 960,000 hits. Expected chromosome 21 CN=3
and sex-chromosome pattern XXY were recovered in every timed run.

Each row below is **one timing**, on a shared Linux environment, using GCC
13.3.0, `-O3 -DNDEBUG`, portable C++17 flags. Peak RSS was measured from
`wait4` child resource usage, not inferred from table size. No competing
test/compilation job was deliberately run during the final timings. OS cache,
host scheduling, compression ratio and small-panel cache locality affect
these results; no confidence interval or large-WGS extrapolation is claimed.

| Input | Counting workers | FASTQ scan seconds | Library load seconds | End-to-end seconds | Sequence Mb/s during scan | Peak RSS MiB |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Plain FASTQ | 1 | 1.377 | 0.249 | 1.631 | 104.6 | 20.7 |
| Plain FASTQ | 4 | 0.958 | 0.233 | 1.196 | 150.3 | 21.1 |
| gzip FASTQ | 1 | 1.434 | 0.252 | 1.692 | 100.4 | 21.3 |
| gzip FASTQ | 4 | 1.414 | 0.235 | 1.654 | 101.9 | 20.2 |

The extra reader thread is present even with one counting worker. Four
workers improved this plain-FASTQ scan by about 1.44×. Gzip barely improved
with additional workers because parsing/decompression is serial. This is a
material scaling limit of the current implementation.

The plain FASTQ occupied 308,048,890 bytes and its gzip level-1 version
54,691,378 bytes. The marker lookup + Bloom structures occupied 8.25 MiB;
remaining RSS includes buffers, strings, metadata and thread/runtime overhead.

To recreate the input and inspect internal timing fields:

```bash
python tools/make_demo.py --out benchmark \
  --markers-per-chromosome 10000 --repeats 2 --random-flanks
./chromkmer --library benchmark/synthetic.markers.tsv \
  --fastq benchmark/synthetic.fastq -t 1 -o benchmark/t1
./chromkmer --library benchmark/synthetic.markers.tsv \
  --fastq benchmark/synthetic.fastq -t 4 -o benchmark/t4
```

Raw benchmark summaries are bundled under `validation/`. Synthetic reads and
their full FASTQ are not bundled. The generator's known words are randomly
generated test sequences, not a human genome-derived marker library.

## What is not established

* Real human WGS dosage accuracy, GC/sequence-bias calibration, marker
  stability across populations, or read-platform equivalence.
* Clinical aneuploidy sensitivity/specificity or low-level mosaic detection.
* A real human single-copy marker library.
* Full-size multi-million-marker, real-depth WGS throughput or peak memory.
* Proportional speedup with thread count; gzip is particularly reader-limited.
* Conda source-build/package testing, conda-channel publication, native
  Windows support, or macOS verification. A standard conda environment and
  precompiled-package recipe are supplied for deployment work.
