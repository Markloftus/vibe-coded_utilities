#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cctype>
#include <cmath>
#include <condition_variable>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <deque>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>
#include <zlib.h>
#include <unistd.h>

namespace fs = std::filesystem;
constexpr const char* VERSION = "0.1.0";
constexpr uint64_t EMPTY = UINT64_MAX;
using Counts = std::vector<uint64_t>;
struct Options {
    std::string library, output = "chromkmer";
    std::vector<std::string> fastq;
    int threads = 4, min_baseq = 0;
    size_t batch_bases = 1000000, queue_batches = 0, max_read = 10000000;
    size_t max_table_mb = 2048, min_markers = 1000, min_baseline = 5;
    double min_expected = 1000, tolerance = .25, max_baseline_mad = .15;
    std::vector<int> baseline;
    bool force = false;
};
std::string chrname(int c) { return c == 22 ? "X" : c == 23 ? "Y" : std::to_string(c + 1); }
int chrid(std::string s) {
    for (char& c : s) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
    if (s.rfind("CHR", 0) == 0) s.erase(0, 3);
    if (s == "X") return 22;
    if (s == "Y") return 23;
    for (int i = 1; i <= 22; ++i) if (s == std::to_string(i)) return i - 1;
    throw std::runtime_error("Unsupported chromosome '" + s + "'; use 1..22, X, Y (optional chr prefix)");
}
void help() {
    std::cout << R"(ChromKmer 0.1.0: exact canonical k-mer chromosome dosage from FASTQ
Usage: chromkmer --library markers.tsv[.gz] --fastq reads.fq[.gz] [options]
       --fastq may be repeated; all input files must belong to ONE sample.

Required:
  --library PATH            Whitespace-separated KMER CHROMOSOME [BIN]
  --fastq PATH              FASTQ, plain or gzip; '-' for stdin (once)
Options:
  -t, --threads INT          Counting workers [4]; reader is one extra thread
  -o, --output PREFIX        Output prefix [chromkmer]
  --min-baseq INT            Minimum Phred+33 quality for every base in a hit [0]
  --batch-bases INT          Approximate bases per queued batch [1000000]
  --queue-batches INT        Maximum waiting batches [2 * workers]
  --max-read-bases INT       Reject reads longer than this [10000000]
  --max-table-mb INT         Guard for lookup + Bloom table allocation [2048 MiB]
  --baseline LIST           Comma-separated baseline autosomes [available 1..22]
  --min-baseline INT         Minimum usable baseline autosomes [5; minimum 3]
  --min-markers INT          Markers per chromosome required for calls [1000]
  --min-expected-hits NUM    Expected hits for one copy required for calls [1000]
  --call-tolerance NUM       Distance from integer CN allowed for calls [0.25]
  --max-baseline-mad NUM     Max median absolute deviation / baseline [0.15]
  --force                   Replace existing output files
  --version                 Print version
  -h, --help                Print help

All markers must have the same k (1..31), be globally single-copy in a haploid
reference (both strands), and be assigned to one chromosome. Duplicate or
reverse-complement duplicate markers are rejected. No reference/BED is needed.
Calls are research screening candidates, not validated karyotype diagnoses.
)";
}
uint64_t uintarg(const std::string& s, const std::string& flag) {
    if (s.empty() || s[0] == '-') throw std::runtime_error("Invalid value for " + flag);
    size_t p; unsigned long long n;
    try { n = std::stoull(s, &p); } catch (...) { throw std::runtime_error("Invalid value for " + flag); }
    if (p != s.size()) throw std::runtime_error("Invalid value for " + flag);
    return n;
}
double doublearg(const std::string& s, const std::string& flag) {
    size_t p; double n;
    try { n = std::stod(s, &p); } catch (...) { throw std::runtime_error("Invalid value for " + flag); }
    if (p != s.size() || !std::isfinite(n)) throw std::runtime_error("Invalid value for " + flag);
    return n;
}
Options parse(int argc, char** argv) {
    Options o;
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--help" || a == "-h") { help(); std::exit(0); }
        if (a == "--version") { std::cout << VERSION << '\n'; std::exit(0); }
        if (a == "--force") { o.force = true; continue; }
        if (++i == argc) throw std::runtime_error("Missing value after " + a);
        std::string v = argv[i];
        if (a == "--library") o.library = v;
        else if (a == "--fastq") o.fastq.push_back(v);
        else if (a == "--output" || a == "-o") o.output = v;
        else if (a == "--threads" || a == "-t") {
            auto n = uintarg(v,a); if (n < 1 || n > 1024) throw std::runtime_error("threads must be 1..1024"); o.threads = n;
        } else if (a == "--min-baseq") {
            auto n = uintarg(v,a); if (n > 93) throw std::runtime_error("min-baseq must be 0..93"); o.min_baseq = n;
        } else if (a == "--batch-bases") o.batch_bases = uintarg(v,a);
        else if (a == "--queue-batches") o.queue_batches = uintarg(v,a);
        else if (a == "--max-read-bases") o.max_read = uintarg(v,a);
        else if (a == "--max-table-mb") o.max_table_mb = uintarg(v,a);
        else if (a == "--min-markers") o.min_markers = uintarg(v,a);
        else if (a == "--min-baseline") o.min_baseline = uintarg(v,a);
        else if (a == "--min-expected-hits") o.min_expected = doublearg(v,a);
        else if (a == "--call-tolerance") o.tolerance = doublearg(v,a);
        else if (a == "--max-baseline-mad") o.max_baseline_mad = doublearg(v,a);
        else if (a == "--baseline") {
            std::istringstream ss(v); std::string s;
            while (std::getline(ss,s,',')) { int c=chrid(s); if(c>=22) throw std::runtime_error("Baseline must contain only autosomes"); o.baseline.push_back(c); }
            std::sort(o.baseline.begin(),o.baseline.end());
            if (o.baseline.empty() || std::adjacent_find(o.baseline.begin(),o.baseline.end()) != o.baseline.end()) throw std::runtime_error("Empty or duplicate baseline list");
        } else throw std::runtime_error("Unknown option " + a);
    }
    if (o.library.empty() || o.fastq.empty() || o.output.empty()) throw std::runtime_error("--library, --fastq and a nonempty output prefix are required");
    if (o.library == "-") throw std::runtime_error("Library must be a file: it is read twice");
    if (!o.batch_bases || !o.max_read || !o.max_table_mb || !o.min_markers || o.min_baseline < 3 || o.min_baseline > 22 || o.min_expected <= 0 || o.tolerance <= 0 || o.tolerance >= .5 || o.max_baseline_mad <= 0) throw std::runtime_error("Invalid memory, QC or call threshold");
    if (o.max_table_mb > SIZE_MAX / (1024*1024)) throw std::runtime_error("max-table-mb too large");
    if (!o.queue_batches) o.queue_batches = static_cast<size_t>(o.threads) * 2;
    std::vector<std::string> paths;
    for (const auto& f : o.fastq) {
        std::string p=f=="-" ? "-" : fs::weakly_canonical(f).string();
        if (std::find(paths.begin(),paths.end(),p)!=paths.end()) throw std::runtime_error("Repeated FASTQ input: " + f);
        paths.push_back(p);
    }
    return o;
}

// gzread transparently accepts uncompressed files. Own buffers, no full-file loads.
class TextInput {
    gzFile f = nullptr;
    std::vector<char> buf = std::vector<char>(1<<20);
    size_t pos = 0, end = 0, max_line;
    std::string path;
public:
    TextInput(const std::string& p, size_t m) : max_line(m), path(p) {
        if (p == "-") { int fd = dup(STDIN_FILENO); if(fd>=0) { f=gzdopen(fd,"rb"); if(!f) close(fd); } }
        else f = gzopen(p.c_str(),"rb");
        if (!f) throw std::runtime_error("Cannot open " + p);
        gzbuffer(f,1<<20);
    }
    ~TextInput() { if (f) gzclose(f); }
    TextInput(const TextInput&) = delete;
    bool line(std::string& out) {
        out.clear();
        for (;;) {
            if (pos == end) {
                int n = gzread(f,buf.data(),static_cast<unsigned>(buf.size()));
                if (n <= 0) {
                    int code; const char* err=gzerror(f,&code);
                    if(n<0 || (code!=Z_OK && code!=Z_STREAM_END)) throw std::runtime_error("Read/decompression error in " + path + ": " + err);
                    if (!out.empty() && out.back()=='\r') out.pop_back();
                    return !out.empty();
                }
                pos=0; end=static_cast<size_t>(n);
            }
            const char* nl=static_cast<const char*>(std::memchr(buf.data()+pos,'\n',end-pos));
            size_t stop=nl ? static_cast<size_t>(nl-buf.data()) : end;
            if (out.size() > max_line || stop-pos > max_line-out.size()) throw std::runtime_error("Line exceeds configured size limit in " + path);
            out.append(buf.data()+pos,stop-pos); pos=stop;
            if (nl) { ++pos; if(!out.empty() && out.back()=='\r') out.pop_back(); return true; }
        }
    }
};
constexpr std::array<int8_t,256> make_base_table() {
    std::array<int8_t,256> table{};
    for(size_t i=0;i<table.size();++i) table[i]=-1;
    table['A']=table['a']=0; table['C']=table['c']=1;
    table['G']=table['g']=2; table['T']=table['t']=3;
    return table;
}
constexpr auto BASE_TABLE=make_base_table();
int base(unsigned char c) { return BASE_TABLE[c]; }
uint64_t encode(const std::string& s) {
    uint64_t f=0,r=0;
    for (size_t i=0;i<s.size();++i) {
        int b=base(s[i]); if(b<0) throw std::runtime_error("Library k-mers must contain only A/C/G/T");
        f=(f<<2)|b; r|=static_cast<uint64_t>(3-b)<<(2*i);
    }
    return std::min(f,r);
}
uint64_t hashkey(uint64_t x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x^(x>>30))*0xbf58476d1ce4e5b9ULL;
    x = (x^(x>>27))*0x94d049bb133111ebULL;
    return x^(x>>31);
}
size_t power2(size_t n) {
    size_t p=1;
    while(p<n) { if(p>SIZE_MAX/2) throw std::runtime_error("Library too large"); p*=2; }
    return p;
}
struct Group { int chr; std::string name; uint64_t markers=0; bool explicit_bin; };
struct Row { std::string kmer, bin; int chr; bool explicit_bin; };
bool library_row(const std::string& line, Row& row) {
    auto start=line.find_first_not_of(" \t\r");
    if (start==std::string::npos || line[start]=='#') return false;
    std::istringstream s(line); std::string chrom,extra;
    if (!(s>>row.kmer>>chrom)) throw std::runtime_error("Library needs KMER CHROMOSOME [BIN] per row");
    if ((row.kmer=="kmer" || row.kmer=="KMER") && (chrom=="chromosome" || chrom=="CHROMOSOME" || chrom=="chrom")) return false;
    row.explicit_bin=static_cast<bool>(s>>row.bin);
    if (!row.explicit_bin) row.bin="all";
    if(s>>extra) throw std::runtime_error("Too many library columns; expected KMER CHROMOSOME [BIN]");
    row.chr=chrid(chrom);
    return true;
}
struct Slot { uint64_t key=EMPTY; uint32_t group=0; uint32_t padding=0; };
static_assert(sizeof(Slot)==16,"Unexpected hash table layout");
class Library {
    std::vector<Slot> slots;
    std::vector<uint64_t> bloom;
    size_t mask=0,bloom_mask=0;
    bool maybe(uint64_t h) const {
        size_t a=h&bloom_mask,b=(h>>32)&bloom_mask;
        return ((bloom[a>>6]>>(a&63))&1) && ((bloom[b>>6]>>(b&63))&1);
    }
public:
    std::vector<Group> groups;
    std::array<uint64_t,24> markers{};
    int k=0;
    size_t bytes=0, marker_total=0;
    uint64_t fingerprint=14695981039346656037ULL;
    explicit Library(const Options& o) {
        std::unordered_map<std::string,uint32_t> ids;
        std::array<int,24> bin_modes; bin_modes.fill(-1);
        {
            TextInput in(o.library,1048576); std::string line; Row row; size_t nline=0;
            while(in.line(line)) {
                ++nline;
                // FNV-1a over decompressed lines plus LF, for change detection, not security.
                for(unsigned char c:line) { fingerprint^=c; fingerprint*=1099511628211ULL; }
                fingerprint^='\n'; fingerprint*=1099511628211ULL;
                try {
                    if(!library_row(line,row)) continue;
                    if(row.kmer.empty() || row.kmer.size()>31) throw std::runtime_error("k must be 1..31");
                    if(!k) k=row.kmer.size();
                    if(static_cast<int>(row.kmer.size())!=k) throw std::runtime_error("Mixed k-mer lengths");
                    encode(row.kmer);
                    if(bin_modes[row.chr]>=0 && bin_modes[row.chr]!=row.explicit_bin) throw std::runtime_error("Do not mix binned and unbinned markers within a chromosome");
                    bin_modes[row.chr]=row.explicit_bin;
                    std::string key=std::to_string(row.chr)+"\t"+row.bin;
                    auto it=ids.find(key);
                    uint32_t id;
                    if(it==ids.end()) {
                        if(groups.size()>=UINT32_MAX) throw std::runtime_error("Too many bins");
                        id=groups.size(); ids.emplace(key,id); groups.push_back({row.chr,row.bin,0,row.explicit_bin});
                    } else id=it->second;
                    ++groups[id].markers; ++markers[row.chr]; ++marker_total;
                } catch(const std::exception& e) { throw std::runtime_error("Library line " + std::to_string(nline) + ": " + e.what()); }
            }
        }
        if(!marker_total) throw std::runtime_error("Empty k-mer library");
        if(marker_total>SIZE_MAX/16) throw std::runtime_error("Library too large");
        size_t capacity=power2(marker_total+marker_total/2+1);
        size_t bits=power2(std::max<size_t>(64,marker_total*8));
        if(capacity>SIZE_MAX/sizeof(Slot) || capacity*sizeof(Slot)>SIZE_MAX-bits/8) throw std::runtime_error("Library too large");
        bytes=capacity*sizeof(Slot)+bits/8;
        if(bytes>o.max_table_mb*1024*1024) throw std::runtime_error("Lookup table needs " + std::to_string(bytes/(1024*1024)+1) + " MiB; increase --max-table-mb or reduce panel size");
        slots.resize(capacity); bloom.resize(bits/64); mask=capacity-1; bloom_mask=bits-1;
        TextInput in(o.library,1048576); std::string line; Row row; size_t nline=0,ninsert=0;
        uint64_t second_fingerprint=14695981039346656037ULL;
        while(in.line(line)) {
            ++nline;
            for(unsigned char c:line) { second_fingerprint^=c; second_fingerprint*=1099511628211ULL; }
            second_fingerprint^='\n'; second_fingerprint*=1099511628211ULL;
            if(!library_row(line,row)) continue;
            if(static_cast<int>(row.kmer.size())!=k || ++ninsert>marker_total) throw std::runtime_error("Library changed between passes");
            auto it=ids.find(std::to_string(row.chr)+"\t"+row.bin);
            if(it==ids.end()) throw std::runtime_error("Library changed between passes");
            uint64_t key=encode(row.kmer),h=hashkey(key); size_t p=h&mask;
            while(slots[p].key!=EMPTY) {
                if(slots[p].key==key) throw std::runtime_error("Duplicate canonical k-mer at library line " + std::to_string(nline) + " (including reverse complements); no duplicates are allowed");
                p=(p+1)&mask;
            }
            slots[p].key=key; slots[p].group=it->second;
            size_t a=h&bloom_mask,b=(h>>32)&bloom_mask;
            bloom[a>>6]|=1ULL<<(a&63); bloom[b>>6]|=1ULL<<(b&63);
        }
        if(ninsert!=marker_total || fingerprint!=second_fingerprint) throw std::runtime_error("Library changed between passes");
    }
    uint32_t lookup(uint64_t key) const {
        uint64_t h=hashkey(key);
        if(!maybe(h)) return UINT32_MAX;
        size_t p=h&mask;
        while(slots[p].key!=EMPTY) {
            if(slots[p].key==key) return slots[p].group;
            p=(p+1)&mask;
        }
        return UINT32_MAX;
    }
};

struct Read { std::string seq,qual; };
struct Batch { std::vector<Read> reads; size_t bases=0; };
class Queue {
    std::mutex mutex;
    std::condition_variable available,space;
    std::deque<Batch> batches;
    size_t capacity;
    bool closed=false,cancelled=false;
public:
    explicit Queue(size_t n) : capacity(n) {}
    void push(Batch&& b) {
        std::unique_lock<std::mutex> lock(mutex);
        space.wait(lock,[&]{return batches.size()<capacity || cancelled;});
        if(cancelled) throw std::runtime_error("Workers stopped");
        batches.push_back(std::move(b)); available.notify_one();
    }
    bool pop(Batch& b) {
        std::unique_lock<std::mutex> lock(mutex);
        available.wait(lock,[&]{return !batches.empty() || closed || cancelled;});
        if(cancelled || batches.empty()) return false;
        b=std::move(batches.front()); batches.pop_front(); space.notify_one(); return true;
    }
    void close(bool cancel=false) {
        std::lock_guard<std::mutex> lock(mutex); closed=true; cancelled=cancelled || cancel;
        if(cancel) batches.clear();
        available.notify_all(); space.notify_all();
    }
};
struct Stats {
    Counts hits;
    uint64_t reads=0,bases=0,valid_kmers=0,matched_reads=0,total_hits=0;
    explicit Stats(size_t n) : hits(n,0) {}
};
void scan(const Read& read, const Library& lib, const Options& o, Stats& stats) {
    uint64_t forward=0,reverse=0,mask=(1ULL<<(2*lib.k))-1;
    int run=0,shift=2*(lib.k-1); bool matched=false;
    ++stats.reads; stats.bases+=read.seq.size();
    for(size_t i=0;i<read.seq.size();++i) {
        int b=base(read.seq[i]);
        if(b<0 || (o.min_baseq && static_cast<unsigned char>(read.qual[i])-33<o.min_baseq)) {run=0;forward=reverse=0;continue;}
        forward=((forward<<2)|b)&mask;
        reverse=(reverse>>2)|(static_cast<uint64_t>(3-b)<<shift);
        if(run<lib.k) ++run;
        if(run==lib.k) {
            ++stats.valid_kmers;
            uint32_t g=lib.lookup(std::min(forward,reverse));
            if(g!=UINT32_MAX) { ++stats.hits[g]; ++stats.total_hits; matched=true; }
        }
    }
    stats.matched_reads+=matched;
}
bool next_read(TextInput& in, Read& r, const Options& o, uint64_t number) {
    std::string line;
    if(!in.line(line)) return false;
    if(line.empty() || line[0]!='@') throw std::runtime_error("Expected @ FASTQ header at record " + std::to_string(number));
    r.seq.clear(); r.qual.clear(); bool plus=false;
    while(in.line(line)) {
        if(!line.empty() && line[0]=='+') {plus=true;break;}
        if(line.size()>o.max_read-r.seq.size()) throw std::runtime_error("Read exceeds --max-read-bases");
        for(unsigned char c:line) if(!std::isalpha(c) && c!='.' && c!='-' && c!='=') throw std::runtime_error("Invalid FASTQ sequence character");
        r.seq+=line;
    }
    if(!plus || r.seq.empty()) throw std::runtime_error("Missing + line or empty sequence in FASTQ record " + std::to_string(number));
    size_t qlen=0;
    while(qlen<r.seq.size() && in.line(line)) {
        for(unsigned char c:line) if(c<33 || c>126) throw std::runtime_error("FASTQ qualities must be printable Phred+33");
        if(line.size()>r.seq.size()-qlen) throw std::runtime_error("Quality length exceeds sequence length in record " + std::to_string(number));
        qlen+=line.size(); if(o.min_baseq) r.qual+=line;
    }
    if(qlen!=r.seq.size()) throw std::runtime_error("Truncated FASTQ quality in record " + std::to_string(number));
    return true;
}
Stats count(const Options& o,const Library& lib) {
    Queue queue(o.queue_batches);
    std::vector<Stats> stats;
    stats.reserve(o.threads);
    for(int i=0;i<o.threads;++i) stats.emplace_back(lib.groups.size());
    std::vector<std::thread> workers;
    std::exception_ptr worker_error; std::mutex error_mutex;
    try {
        for(int i=0;i<o.threads;++i) workers.emplace_back([&,i] {
            try {
                Batch b;
                while(queue.pop(b)) { for(const auto& r:b.reads) scan(r,lib,o,stats[i]); b=Batch{}; }
            } catch(...) {
                { std::lock_guard<std::mutex> lock(error_mutex); if(!worker_error) worker_error=std::current_exception(); }
                queue.close(true);
            }
        });
        Batch batch;
        for(const auto& path:o.fastq) {
            TextInput in(path,std::max<size_t>(o.max_read,1048576)); uint64_t n=0;
            for(;;) {
                Read r;
                try { if(!next_read(in,r,o,n+1)) break; } catch(const std::exception& e) {throw std::runtime_error(path + ": " + e.what());}
                ++n; batch.bases+=r.seq.size(); batch.reads.push_back(std::move(r));
                if(batch.bases>=o.batch_bases) { queue.push(std::move(batch)); batch=Batch{}; }
            }
        }
        if(!batch.reads.empty()) queue.push(std::move(batch));
        queue.close();
    } catch(...) {
        queue.close(true); for(auto& t:workers) t.join();
        if(worker_error) std::rethrow_exception(worker_error);
        throw;
    }
    for(auto& t:workers) t.join();
    if(worker_error) std::rethrow_exception(worker_error);
    Stats all(lib.groups.size());
    for(const auto& s:stats) {
        all.reads+=s.reads; all.bases+=s.bases; all.valid_kmers+=s.valid_kmers;
        all.matched_reads+=s.matched_reads; all.total_hits+=s.total_hits;
        for(size_t g=0;g<all.hits.size();++g) all.hits[g]+=s.hits[g];
    }
    if(!all.reads) throw std::runtime_error("No FASTQ records found");
    return all;
}
double median(std::vector<double> v) {
    if(v.empty()) return std::numeric_limits<double>::quiet_NaN();
    size_t m=v.size()/2; std::nth_element(v.begin(),v.begin()+m,v.end()); double x=v[m];
    if(v.size()%2==0) x=(x+*std::max_element(v.begin(),v.begin()+m))/2;
    return x;
}
struct Result {
    uint64_t hits=0;
    size_t bins=0;
    double density=NAN,cn=NAN,expected=NAN,bin_cv=NAN;
    int integer=-1;
    std::vector<std::string> flags;
    std::string call="UNCERTAIN";
};
struct Analysis {
    std::array<Result,24> r;
    std::vector<int> baseline;
    double depth=0,mad=NAN;
    bool baseline_ok=false;
    std::string pattern="UNRESOLVED";
    std::vector<std::string> warnings;
};
Analysis analyze(const Options& o,const Library& lib,const Stats& stats) {
    Analysis a;
    for(size_t g=0;g<lib.groups.size();++g) { a.r[lib.groups[g].chr].hits+=stats.hits[g]; a.r[lib.groups[g].chr].bins+=lib.groups[g].explicit_bin; }
    std::vector<int> candidates=o.baseline;
    if(candidates.empty()) for(int c=0;c<22;++c) if(lib.markers[c]) candidates.push_back(c);
    std::vector<double> density;
    for(int c=0;c<24;++c) if(lib.markers[c]) a.r[c].density=static_cast<double>(a.r[c].hits)/lib.markers[c];
    for(int c:candidates) {
        if(!lib.markers[c] && !o.baseline.empty()) throw std::runtime_error("Requested baseline chromosome is missing from library: " + chrname(c));
        // A putatively diploid baseline must have enough markers and observed evidence.
        if(lib.markers[c]>=o.min_markers && a.r[c].hits>=2*o.min_expected) { a.baseline.push_back(c); density.push_back(a.r[c].density); }
    }
    if(a.baseline.size()<o.min_baseline) throw std::runtime_error("Too few adequately covered baseline autosomes (" + std::to_string(a.baseline.size()) + "); need " + std::to_string(o.min_baseline) + ". Check depth, markers, and thresholds; no CN outputs written");
    a.depth=median(density);
    if(!(a.depth>0)) throw std::runtime_error("No positive autosomal baseline");
    std::vector<double> dev; for(double d:density) dev.push_back(std::abs(d-a.depth));
    a.mad=median(dev)/a.depth; a.baseline_ok=a.mad<=o.max_baseline_mad;
    if(!a.baseline_ok) a.warnings.push_back("BASELINE_DISPERSION_HIGH: all integer calls suppressed");
    if(a.baseline.size()<22) a.warnings.push_back("INCOMPLETE_BASELINE: fewer than 22 autosomes contributed");
    if(lib.k<15) a.warnings.push_back("K_BELOW_15: small k is unsuitable for globally unique human markers");
    for(int c=0;c<24;++c) {
        auto& r=a.r[c];
        if(!lib.markers[c]) {r.flags.push_back("NO_MARKERS");r.call="NOT_ASSESSED";continue;}
        r.cn=2*r.density/a.depth; r.expected=a.depth*.5*lib.markers[c];
        bool ok=a.baseline_ok;
        if(lib.markers[c]<o.min_markers) {r.flags.push_back("TOO_FEW_MARKERS");ok=false;}
        if(r.expected<o.min_expected) {r.flags.push_back("LOW_EXPECTED_HITS");ok=false;}
        if(!a.baseline_ok) r.flags.push_back("BASELINE_DISPERSION_HIGH");
        if(r.bins<5) r.flags.push_back("LIMITED_BIN_QC");
        else {
            // Unweighted bin CV is diagnostic only: bins differ in marker count and
            // overlapping k-mers create correlated counts. No confidence intervals.
            std::vector<double> values;
            for(size_t g=0;g<lib.groups.size();++g) if(lib.groups[g].chr==c) values.push_back(static_cast<double>(stats.hits[g])/lib.groups[g].markers);
            double mean=0; for(double d:values) mean+=d; mean/=values.size();
            if(mean>0) {double v=0;for(double d:values) v+=(d-mean)*(d-mean);r.bin_cv=std::sqrt(v/values.size())/mean;}
            if(std::isfinite(r.bin_cv) && r.bin_cv>.5) {r.flags.push_back("BIN_HETEROGENEITY_HIGH");ok=false;}
        }
        double rounded=std::round(r.cn);
        if(rounded>1000 || std::abs(r.cn-rounded)>o.tolerance) {r.flags.push_back("NONINTEGER_DOSAGE");ok=false;}
        if(ok) {
            r.integer=static_cast<int>(rounded);
            if(c<22) r.call=r.integer==2 ? "DISOMIC_CANDIDATE" : r.integer==3 ? "TRISOMY_CANDIDATE" : r.integer==1 ? "MONOSOMY_CANDIDATE" : r.integer==0 ? "ABSENT_CANDIDATE" : "GAIN_CANDIDATE";
            else r.call="CN"+std::to_string(r.integer)+"_CANDIDATE";
        }
    }
    int x=a.r[22].integer,y=a.r[23].integer;
    if(x==1 && y==0) a.pattern="X0";
    else if(x==1 && y==1) a.pattern="XY";
    else if(x==2 && y==0) a.pattern="XX";
    else if(x==2 && y==1) a.pattern="XXY";
    else if(x==1 && y==2) a.pattern="XYY";
    else if(x==3 && y==0) a.pattern="XXX";
    else if(x==2 && y==2) a.pattern="XXYY";
    else if(x>=0 && y>=0) a.pattern="OTHER_X"+std::to_string(x)+"_Y"+std::to_string(y);
    return a;
}
std::string json(const std::string& s) {
    std::ostringstream out;out<<'"';
    for(unsigned char c:s) {
        if(c=='"' || c=='\\') out<<'\\'<<c;
        else if(c<32) out<<"\\u"<<std::hex<<std::setw(4)<<std::setfill('0')<<static_cast<int>(c)<<std::dec;
        else out<<c;
    }
    out<<'"';return out.str();
}
std::string num(double d) { if(!std::isfinite(d)) return "NA"; std::ostringstream s;s<<std::setprecision(10)<<d;return s.str(); }
std::string flags(const std::vector<std::string>& v) {std::string s;for(const auto& f:v){if(!s.empty())s+=';';s+=f;}return s.empty()?"PASS_BASIC_QC":s;}
std::vector<fs::path> output_paths(const Options& o) {return {o.output+".chromosomes.tsv",o.output+".bins.tsv",o.output+".report.json"};}
void preflight_outputs(const Options& o) {
    auto paths=output_paths(o);
    for(const auto& p:paths) {
        if(fs::exists(p) && (!o.force || !fs::is_regular_file(p))) throw std::runtime_error("Output exists or is not a regular file: " + p.string() + "; use another prefix or --force");
        fs::path canon=fs::weakly_canonical(p);
        if(canon==fs::weakly_canonical(o.library)) throw std::runtime_error("Output would overwrite library");
        for(const auto& f:o.fastq) if(f!="-" && canon==fs::weakly_canonical(f)) throw std::runtime_error("Output would overwrite input FASTQ");
    }
    fs::path parent=paths[0].parent_path(); if(!parent.empty()) fs::create_directories(parent);
}
void write_outputs(const Options& o,const Library& lib,const Stats& stats,const Analysis& a,double load_seconds,double scan_seconds) {
    auto paths=output_paths(o);std::vector<fs::path> temps;
    // Each file is staged beside its destination and renamed after all writes.
    // The three renames are not a single filesystem transaction.
    for(const auto& p:paths) temps.push_back(p.string()+".tmp."+std::to_string(getpid()));
    for(const auto& t:temps) if(fs::exists(t)) throw std::runtime_error("Temporary output already exists: "+t.string());
    try {
        std::ofstream chrom(temps[0]),bins(temps[1]),report(temps[2]);
        if(!chrom || !bins || !report) throw std::runtime_error("Cannot create output files");
        chrom<<"chromosome\tmarkers\thits\thits_per_marker\tcopy_number\tnearest_integer_candidate\tcall\texpected_hits_per_single_copy\texplicit_bins\tbin_cv\tqc\n";
        for(int c=0;c<24;++c) {
            const auto& r=a.r[c];
            chrom<<chrname(c)<<'\t'<<lib.markers[c]<<'\t'<<r.hits<<'\t'<<num(r.density)<<'\t'<<num(r.cn)<<'\t'<<(r.integer<0?"NA":std::to_string(r.integer))<<'\t'<<r.call<<'\t'<<num(r.expected)<<'\t'<<r.bins<<'\t'<<num(r.bin_cv)<<'\t'<<flags(r.flags)<<'\n';
        }
        bins<<"chromosome\tbin\tmarkers\thits\thits_per_marker\tcopy_number\texplicit_bin\n";
        for(size_t g=0;g<lib.groups.size();++g) {
            const auto& group=lib.groups[g];double d=static_cast<double>(stats.hits[g])/group.markers;
            bins<<chrname(group.chr)<<'\t'<<group.name<<'\t'<<group.markers<<'\t'<<stats.hits[g]<<'\t'<<num(d)<<'\t'<<num(2*d/a.depth)<<'\t'<<group.explicit_bin<<'\n';
        }
        report<<"{\n  \"program\": \"ChromKmer\",\n  \"version\": "<<json(VERSION)<<",\n  \"status\": \"EXPERIMENTAL_RESEARCH_SCREEN\",\n  \"library\": "<<json(o.library)<<",\n  \"library_fingerprint_fnv1a64_normalized_lines\": \""<<std::hex<<lib.fingerprint<<std::dec<<"\",\n  \"k\": "<<lib.k<<",\n  \"library_markers\": "<<lib.marker_total<<",\n  \"lookup_and_bloom_bytes\": "<<lib.bytes<<",\n  \"worker_counter_bytes\": "<<static_cast<size_t>(o.threads)*lib.groups.size()*sizeof(uint64_t)<<",\n  \"fastq\": [";
        for(size_t i=0;i<o.fastq.size();++i) {if(i)report<<", ";report<<json(o.fastq[i]);}
        report<<"],\n  \"threads\": "<<o.threads<<",\n  \"min_baseq\": "<<o.min_baseq<<",\n  \"batch_bases\": "<<o.batch_bases<<",\n  \"queue_batches\": "<<o.queue_batches<<",\n  \"max_read_bases\": "<<o.max_read<<",\n  \"reads\": "<<stats.reads<<",\n  \"bases\": "<<stats.bases<<",\n  \"valid_kmer_positions\": "<<stats.valid_kmers<<",\n  \"matched_reads\": "<<stats.matched_reads<<",\n  \"marker_occurrences\": "<<stats.total_hits<<",\n  \"library_load_seconds\": "<<num(load_seconds)<<",\n  \"fastq_scan_seconds\": "<<num(scan_seconds)<<",\n  \"scan_megabases_per_second\": "<<num(stats.bases/(1000000.*scan_seconds))<<",\n  \"baseline_assumed_copy_number\": 2,\n  \"baseline_hits_per_marker\": "<<num(a.depth)<<",\n  \"baseline_relative_mad\": "<<num(a.mad)<<",\n  \"baseline_basic_qc_passed\": "<<(a.baseline_ok?"true":"false")<<",\n  \"baseline_chromosomes\": [";
        for(size_t i=0;i<a.baseline.size();++i) {if(i)report<<", ";report<<json(chrname(a.baseline[i]));}
        report<<"],\n  \"min_markers\": "<<o.min_markers<<",\n  \"min_expected_hits_per_single_copy\": "<<num(o.min_expected)<<",\n  \"min_baseline_autosomes\": "<<o.min_baseline<<",\n  \"call_tolerance\": "<<num(o.tolerance)<<",\n  \"max_baseline_relative_mad\": "<<num(o.max_baseline_mad)<<",\n  \"sex_chromosome_pattern_candidate\": "<<json(a.pattern)<<",\n  \"autosomal_change_candidates\": [";
        bool first=true;
        for(int c=0;c<22;++c) if(a.r[c].integer>=0 && a.r[c].integer!=2) {if(!first)report<<", ";first=false;report<<"{\"chromosome\": "<<json(chrname(c))<<", \"copy_number\": "<<num(a.r[c].cn)<<", \"integer_candidate\": "<<a.r[c].integer<<", \"call\": "<<json(a.r[c].call)<<"}";}
        report<<"],\n  \"warnings\": [";
        for(size_t i=0;i<a.warnings.size();++i) {if(i)report<<", ";report<<json(a.warnings[i]);}
        report<<"],\n  \"interpretation\": \"Provisional relative dosage; threshold rules are heuristic, not validated diagnoses or confidence intervals. Most baseline autosomes must be disomic.\"\n}\n";
        chrom.close();bins.close();report.close();
        if(!chrom || !bins || !report) throw std::runtime_error("Output write failed");
        for(size_t i=0;i<paths.size();++i) {if(!o.force && fs::exists(paths[i])) throw std::runtime_error("Output appeared during run: "+paths[i].string());fs::rename(temps[i],paths[i]);}
    } catch(...) {for(const auto& t:temps) {std::error_code ec;fs::remove(t,ec);}throw;}
}
int main(int argc,char** argv) {
    try {
        if(argc==1) {help();return 2;}
        Options o=parse(argc,argv);preflight_outputs(o);
        auto t0=std::chrono::steady_clock::now();
        Library lib(o);
        auto t1=std::chrono::steady_clock::now();
        std::cerr<<"Loaded "<<lib.marker_total<<" canonical "<<lib.k<<"-mer markers; lookup + Bloom "<<num(lib.bytes/1048576.)<<" MiB; "<<o.threads<<" counting workers\n";
        Stats stats=count(o,lib);
        auto t2=std::chrono::steady_clock::now();
        Analysis a=analyze(o,lib,stats);
        double load=std::chrono::duration<double>(t1-t0).count(),scan=std::chrono::duration<double>(t2-t1).count();
        write_outputs(o,lib,stats,a,load,scan);
        std::cerr<<"Scanned "<<stats.reads<<" reads ("<<stats.bases<<" bases), "<<stats.total_hits<<" marker occurrences; "<<num(stats.bases/(1000000.*scan))<<" Mb/s\nSex chromosome pattern candidate: "<<a.pattern<<"\n";
        for(int c=0;c<22;++c) if(a.r[c].integer>=0 && a.r[c].integer!=2) std::cerr<<"chr"<<chrname(c)<<": "<<a.r[c].call<<" CN="<<num(a.r[c].cn)<<'\n';
        for(const auto& w:a.warnings) std::cerr<<"QC: "<<w<<'\n';
        std::cerr<<"Wrote "<<o.output<<".{chromosomes.tsv,bins.tsv,report.json}\n";
        return 0;
    } catch(const std::exception& e) {std::cerr<<"ERROR: "<<e.what()<<'\n';return 1;}
}
